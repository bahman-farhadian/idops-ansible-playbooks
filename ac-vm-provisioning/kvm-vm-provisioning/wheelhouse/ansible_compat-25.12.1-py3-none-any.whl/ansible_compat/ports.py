"""Portability helpers."""

from functools import cache, cached_property

__all__ = ["cache", "cached_property"]
